<div class="container-fluid">


   <div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Selamat Datang!</h4>
  <p>Selamat Datang<strong> <?php echo $username; ?> </strong>Di Tampilan Capaian Output <strong><?php echo $level; ?></strong> </p>
  <hr>
 
</div>

<!-- Button trigger modal -->




        

      </div>
    </div>
  </div>
</div>
</div>